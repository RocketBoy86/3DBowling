Hello,

Thank for downloading Dot Zero.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
  https://www.creativefabrica.com/designer/mozyenstudio/

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at Mozyenstudio@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/hasanpass
 
Please visit our store for more amazing fonts : 
https://crella.net/store/mozyenstudio/
https://www.creativefabrica.com/designer/mozyenstudio/
https://fontbundles.net/mozyen-studio

Follow our instagram for update : @Mozyen.studio
Thank you.
